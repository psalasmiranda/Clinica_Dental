class Componente < ApplicationRecord
has_many :tratamientos
has_many :insumos
end
