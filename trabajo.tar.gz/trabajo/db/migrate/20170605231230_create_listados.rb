class CreateListados < ActiveRecord::Migration[5.1]
  def change
    create_table :listados do |t|

      t.timestamps
    end
  end
end
